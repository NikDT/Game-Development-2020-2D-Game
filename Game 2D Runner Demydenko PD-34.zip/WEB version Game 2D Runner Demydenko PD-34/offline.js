﻿{
	"version": 1591520787,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-3.4.1.min.js",
		"offlineClient.js",
		"images/backgroundfirststage.png",
		"images/floorfirststage.png",
		"images/player-sheet0.png",
		"images/player-sheet1.png",
		"images/player-sheet2.png",
		"images/obstaclespikesfirststage-sheet0.png",
		"images/backgroundsecondstage.png",
		"images/floorsecondstage.png",
		"images/pmbackground-sheet0.png",
		"images/sprite-sheet0.png",
		"media/runner.m4a",
		"media/runner.ogg",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png"
	]
}